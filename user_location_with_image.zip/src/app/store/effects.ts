import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { EMPTY, of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { ApiService } from '../api.service'; // Create an API service
import * as apiActions from './actions';

@Injectable()
export class ApiEffects {

  loadData$ = createEffect(() => this.actions$.pipe(
    ofType(apiActions.loadAPIData),
    mergeMap(() => this.apiService.getData()
      .pipe(
        map(data => apiActions.loadAPISuccess({ data })),
        catchError(() => EMPTY)
      )
    )
  ));

  
  // postItem$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(apiActions.postItem),
  //     mergeMap(action =>
  //       this.apiService.postItem(action.item).pipe(
  //         map(item => apiActions.postItem({ item }))
  //       )
  //     )
  //   )
  // );

  postItem$ = createEffect(() =>
    this.actions$.pipe(
      ofType(apiActions.postItem),
      mergeMap(action =>
        this.apiService.postItem(action.item).pipe(
          map(item => apiActions.postItemSuccess({ item })) // Assuming you have a success action
        )
      )
    )
  );

  // postItem$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(apiActions.postItem),
  //     mergeMap(action =>
  //       this.apiService.postItem(action.item).(
  //         map(response => apiActions.postItemSuccess({ response })),
  //         catchError(error => of(apiActions.postItemFailure({ error })))
  //       )
  //     )
  //   )
  // );

  putItem$ = createEffect(() =>
    this.actions$.pipe(
      ofType(apiActions.putItem),
      mergeMap(action =>
        this.apiService.putItem(action.id, action.item).pipe(
          map(item => apiActions.putItemSuccess({ id: action.id, item })) // Assuming you have a success action
        )
      )
    )
  );

  // putItem$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(apiActions.putItem),
  //     mergeMap(action =>
  //       this.apiService.putItem(action.id, action.item).pipe(
  //         map(item => apiActions.putItem({ id: action.id, item }))
  //       )
  //     )
  //   )
  // );

  constructor(private actions$: Actions, private apiService: ApiService) {}
}